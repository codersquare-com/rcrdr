$(document).ready(function(){
    $("#yt-get-elapsed-time").click(function(){
        log_string(yt_current_time);
    });
    
})